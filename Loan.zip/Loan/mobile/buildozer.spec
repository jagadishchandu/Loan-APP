[app]
title = LendSplit
package.name = lendsplit
package.domain = io.lendsplit
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
source.include_patterns = .env
version = 0.1
requirements = python3,kivy,requests
orientation = portrait
fullscreen = 0

android.permissions = INTERNET
android.api = 34
android.minapi = 24

[buildozer]
log_level = 2
warn_on_root = 1
